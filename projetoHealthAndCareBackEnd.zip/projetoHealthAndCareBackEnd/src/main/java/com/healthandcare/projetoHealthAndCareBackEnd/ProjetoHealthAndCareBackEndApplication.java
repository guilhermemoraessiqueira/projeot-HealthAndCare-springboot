package com.healthandcare.projetoHealthAndCareBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoHealthAndCareBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoHealthAndCareBackEndApplication.class, args);
	}

}
